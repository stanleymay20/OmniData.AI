"""
OmniData.AI - Enterprise-grade AI Data Platform
"""

__version__ = "0.1.0" 